## v1.2.1
- Redirecionamento de /wp-login e /wp-admin para /gip-login
- Visual de login atualizado com tema escuro GIP
- Adição de .htaccess com bloqueios e proteção
- Refino final da instalação GIP segura