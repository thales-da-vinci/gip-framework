#!/bin/bash
echo "🔌 Ativando plugins GIP via WP-CLI..."

PLUGINS=(
  "elementor"
  "elementor-pro"
  "wp-file-manager-pro"
  "all-in-one-wp-migration"
  "all-in-one-wp-migration-unlimited-extension"
  "all-in-one-wp-migration-ftp-extension"
  "admin-site-enhancements-pro"
  "wp-mail-smtp-pro"
)

for plugin in "${PLUGINS[@]}"; do
  wp plugin activate "$plugin"
done

echo "✅ Todos os plugins GIP foram ativados com sucesso!"