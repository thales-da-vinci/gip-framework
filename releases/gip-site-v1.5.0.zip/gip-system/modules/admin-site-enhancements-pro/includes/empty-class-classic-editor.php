<?php

/**
 * Empty class for compatibility fixes
 * e.g. So ASE Disable Gutenberg works with Gravity Forms to show "Add Form" button beside "Add Media"
 *
 * @since 6.9.6
 */
class Classic_Editor {

	public function do_nothihg() {
		// We do nothing in this method and class		
	}	

}