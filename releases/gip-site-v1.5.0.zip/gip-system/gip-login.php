<?php
require_once __DIR__ . '/../wp-load.php';
require_once __DIR__ . '/login/functions.php';

if (is_user_logged_in()) {
  wp_redirect(admin_url());
  exit;
}

require_once __DIR__ . '/login/form.php';