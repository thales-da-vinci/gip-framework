# 📚 Documentação do Site GIP

## 🚀 Estrutura
- [`gip-core/`](./gip-core)
- [`gip-system/`](./gip-system)
  - [`layout/`](./gip-system/layout) (temas)
  - [`modules/`](./gip-system/modules) (plugins)
  - [`media/`](./gip-system/media) (uploads)
- [`gip-config.php`](./gip-config.php)
- [`plugin-installer.sh`](./plugin-installer.sh)
- [`changelog.md`](./changelog.md)

## 📦 Metadados
Veja o [`site.json`](./site.json) para detalhes do projeto.

## 🧰 Scripts
- [`deploy.sh`](./deploy.sh)
- [`restore.sh`](./restore.sh)