<?php
// GIP Custom Paths
define('GIP_SYSTEM', __DIR__ . '/gip-system');
define('GIP_LAYOUTS', GIP_SYSTEM . '/layout');
define('GIP_MODULES', GIP_SYSTEM . '/modules');
define('GIP_MEDIA', GIP_SYSTEM . '/media');

// WordPress Path Overrides
define('WP_CONTENT_DIR', GIP_SYSTEM);
define('WP_CONTENT_URL', 'https://' . $_SERVER['HTTP_HOST'] . '/gip-system');
define('WP_PLUGIN_DIR', GIP_SYSTEM . '/modules');
define('WP_PLUGIN_URL', 'https://' . $_SERVER['HTTP_HOST'] . '/gip-system/modules');
define('UPLOADS', 'media');
define('UPLOADS', 'gip-system/media');