# 🌐 GIP-SITE: Site WordPress com Arquitetura Personalizada

Este repositório contém a estrutura completa do site WordPress com arquitetura GIP, sem uso de `wp`, `themes` ou `plugins`.

---

## 📦 Estrutura GIP

```
📁 gip-core/              # Núcleo WP
📁 gip-system/
│   ├── layout/           # Temas (ex: gip-base)
│   ├── modules/          # Plugins
│   └── media/            # Uploads
📄 gip-config.php         # Substituto do wp-config.php
📄 site.json              # Metadados do projeto
📄 changelog.md
📄 deploy.sh
📄 restore.sh
📄 plugin-installer.sh    # Ativação automática via WP-CLI
```

---

## 🚀 Deploy Automático (GitHub Actions)

Configure os secrets no repositório:

- `FTP_USERNAME`
- `FTP_PASSWORD`

---

## 🔌 Plugins Ativos

- Elementor + Pro
- WP Mail SMTP Pro
- All-in-One WP Migration + Unlimited + FTP
- WP File Manager Pro
- Admin Site Enhancements Pro

---

## 🎨 Tema

- `gip-base`: baseado no Hello Elementor