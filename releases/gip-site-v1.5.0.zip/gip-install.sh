#!/bin/bash

echo "🔧 Iniciando instalação GIP Site..."

read -p "📁 Caminho de destino do site (ex: /var/www/cliente): " DEST
read -p "🌐 URL do site (ex: https://cliente.com): " URL
read -p "🔐 Token da API GIP WP Manager: " TOKEN
read -p "🌍 URL do painel GIP (ex: https://painel.com): " API

# Validar
if [ -z "$DEST" ] || [ -z "$URL" ] || [ -z "$TOKEN" ] || [ -z "$API" ]; then
  echo "❌ Faltam parâmetros. Abortando."
  exit 1
fi

mkdir -p "$DEST" || { echo "❌ Não foi possível criar $DEST"; exit 1; }
cp -R . "$DEST" || { echo "❌ Falha ao copiar arquivos para $DEST"; exit 1; }

# Substituir URL
sed -i '' "s|https://seudominio.com|$URL|g" "$DEST/site.json"
sed -i '' "s|https://seudominio.com|$URL|g" "$DEST/gip-config.php"

# Criar log
mkdir -p "$DEST/logs"
echo "[`date`] Site instalado: $URL" >> "$DEST/logs/install.log"

# WP-CLI
if command -v wp &> /dev/null; then
  echo "🔄 Ativando plugins via WP-CLI..."
  wp --path="$DEST" plugin activate $(jq -r '.ativos[]' "$DEST/modules.json")
fi

# Enviar site para painel
echo "📡 Registrando no painel GIP..."
curl -s -X POST "$API/wp-json/gip/v1/sites" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{"cliente":"$DEST","url":"$URL","status":"instalado"}"

# Log remoto
curl -s -X POST "$API/wp-json/gip/v1/logs" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{"site_id":1, "acao":"install", "resposta":"Instalado via CLI para $URL"}"

echo "✅ Instalação concluída com integração REST!"