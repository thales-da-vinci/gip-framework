
<?php
echo "<h1>✅ GIP SITE ATIVO</h1>";
echo "<p>Versão: 1.1.0</p>";
echo "<p>Data: " . date('Y-m-d H:i') . "</p>";
