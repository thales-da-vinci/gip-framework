<?php
defined( 'ABSPATH' ) || die();

class Form_Builder_Field_Matrix_Of_Five_Variable_Dropdowns extends Form_Builder_Field_Matrix_Of_Variable_Dropdowns {

    protected $type = 'matrix_of_variable_dropdowns_five';

}