(function( $ ) {
   'use strict';

   $(document).ready( function() {

   }); // END OF $(document).ready()

})( jQuery );