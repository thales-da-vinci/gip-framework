# 📦 GIP WP Manager - Changelog

## v2.0.0 (1º de Abril de 2025)

- 🔄 Integração com Backuply Pro (backup, restore, GDrive)
- ✉️ Suporte SMTP com fallback (GoSMTP)
- 🧠 Estrutura modular reorganizada
- 💼 Preparação para Deploy, File Manager e JetEngine
- 🧩 Interface visual baseada no Softaculous
- 📄 Inclusão do README.md com instruções detalhadas