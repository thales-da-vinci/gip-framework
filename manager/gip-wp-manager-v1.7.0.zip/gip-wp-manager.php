<?php
/*
Plugin Name: GIP WP Manager
Description: Gerenciador completo de sites GIP com upload, instalação, REST e status.
Version: 1.3.0
*/

require_once plugin_dir_path(__FILE__) . 'admin/zip-upload.php';
require_once plugin_dir_path(__FILE__) . 'rest/api.php';
require_once plugin_dir_path(__FILE__) . 'admin/shortcode.php';
require_once plugin_dir_path(__FILE__) . 'admin/upload-site.php';
require_once plugin_dir_path(__FILE__) . 'admin/rest-deploy.php';
require_once plugin_dir_path(__FILE__) . 'admin/shortcode-sites.php';