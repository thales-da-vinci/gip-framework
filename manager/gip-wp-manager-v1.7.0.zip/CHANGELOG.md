## v1.5.0 - GIP WP Manager
- Suporte a instalação via botão zip
- Upload e deploy de microsites do GIP
- Log por ação e projeto
- Sincronização com JetEngine
- API REST para deploy remoto