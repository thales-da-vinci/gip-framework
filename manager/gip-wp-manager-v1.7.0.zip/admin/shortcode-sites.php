<?php
add_shortcode('gip_site_list', 'gip_render_site_list');

function gip_render_site_list() {
  $base = WP_CONTENT_DIR . '/gip-sites/';
  $html = "<div class='wrap'><h2>Microsites GIP</h2><table class='widefat'><thead><tr><th>Nome</th><th>Path</th></tr></thead><tbody>";

  if (file_exists($base)) {
    foreach (scandir($base) as $site) {
      if ($site === '.' || $site === '..') continue;
      $path = $base . $site;
      if (is_dir($path)) {
        $html .= "<tr><td><strong>$site</strong></td><td><code>$path</code></td></tr>";
      }
    }
  }

  $html .= "</tbody></table></div>";
  return $html;
}