<?php
add_action('admin_menu', function () {
  add_menu_page('Instalar Microsite GIP', 'Instalar GIP', 'manage_options', 'gip-upload', 'gip_upload_page');
});

function gip_upload_page() {
  ?>
  <div class="wrap">
    <h2>Instalar Microsite GIP (.zip)</h2>
    <form method="post" enctype="multipart/form-data">
      <input type="file" name="gip_zip" accept=".zip" required>
      <input type="submit" name="gip_install" class="button button-primary" value="Instalar">
    </form>
  </div>
  <?php

  if (isset($_POST['gip_install'])) {
    $file = $_FILES['gip_zip'];
    $tmp = $file['tmp_name'];
    $name = sanitize_file_name($file['name']);
    $dest = WP_CONTENT_DIR . '/gip-sites/' . basename($name, '.zip');

    if (!file_exists($dest)) {
      mkdir($dest, 0755, true);
    }

    $zip = new ZipArchive();
    if ($zip->open($tmp) === true) {
      $zip->extractTo($dest);
      $zip->close();
      echo "<div class='updated'><p>✅ Microsite instalado com sucesso em <code>$dest</code>.</p></div>";
    } else {
      echo "<div class='error'><p>❌ Falha ao extrair ZIP.</p></div>";
    }
  }
}