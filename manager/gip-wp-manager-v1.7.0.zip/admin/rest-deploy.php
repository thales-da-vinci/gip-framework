<?php
add_action('rest_api_init', function () {
  register_rest_route('gip/v1', '/deploy-site', [
    'methods' => 'POST',
    'callback' => 'gip_deploy_remote_site',
    'permission_callback' => '__return_true'
  ]);
});

function gip_deploy_remote_site($request) {
  $params = $request->get_json_params();
  $name = sanitize_title($params['name'] ?? '');
  $url = esc_url_raw($params['zip_url'] ?? '');
  $dest = WP_CONTENT_DIR . '/gip-sites/' . $name;

  if (!$name || !$url) {
    return new WP_Error('invalid_data', 'Nome e URL são obrigatórios', ['status' => 400]);
  }

  if (!file_exists($dest)) {
    mkdir($dest, 0755, true);
  }

  $tmp = download_url($url);
  if (is_wp_error($tmp)) {
    return new WP_Error('download_error', 'Erro ao baixar o ZIP', ['status' => 500]);
  }

  $zip = new ZipArchive();
  if ($zip->open($tmp) === true) {
    $zip->extractTo($dest);
    $zip->close();
    unlink($tmp);
    return ['success' => true, 'message' => 'Microsite implantado com sucesso', 'path' => $dest];
  } else {
    return new WP_Error('extract_error', 'Falha ao extrair ZIP', ['status' => 500]);
  }
}