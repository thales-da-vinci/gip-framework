<?php
add_action('admin_menu', function () {
  add_menu_page('Instalar ZIP GIP', 'Instalar ZIP', 'manage_options', 'gip-zip-upload', 'gip_zip_upload_page');
});

function gip_zip_upload_page() {
  if (isset($_POST['gip_install']) && isset($_FILES['gip_zip'])) {
    $zip = $_FILES['gip_zip'];
    $slug = sanitize_title($_POST['gip_slug']);
    $dest_root = WP_CONTENT_DIR . '/gip-sites/' . $slug;

    if (!file_exists($dest_root)) {
      mkdir($dest_root, 0755, true);
    }

    $tmp_zip = $dest_root . '/' . basename($zip['name']);
    move_uploaded_file($zip['tmp_name'], $tmp_zip);

    $zip_obj = new ZipArchive();
    if ($zip_obj->open($tmp_zip) === TRUE) {
      $zip_obj->extractTo($dest_root);
      $zip_obj->close();
      unlink($tmp_zip);

      $log = "✅ ZIP extraído para: " . $dest_root;

      if (file_exists($dest_root . '/gip-install.sh')) {
        chmod($dest_root . '/gip-install.sh', 0755);
        shell_exec($dest_root . '/gip-install.sh');
        $log .= "<br>🚀 Script executado.";
      }
    } else {
      $log = "❌ Erro ao extrair o ZIP.";
    }

    echo "<div class='notice notice-success'><p>$log</p></div>";
  }

  echo '<div class="wrap"><h2>📦 Instalar GIP Site via ZIP</h2>';
  echo '<form method="post" enctype="multipart/form-data">';
  echo '<label>Slug do site (ex: cliente1)</label><input type="text" name="gip_slug" required />';
  echo '<input type="file" name="gip_zip" required />';
  echo '<input type="submit" name="gip_install" class="button button-primary" value="Instalar ZIP" />';
  echo '</form></div>';
}