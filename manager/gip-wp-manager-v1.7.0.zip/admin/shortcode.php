<?php
add_shortcode('gip_site_list', function () {
  $sites = wp_remote_get(home_url('/wp-json/gip/v1/sites'));
  $body = json_decode(wp_remote_retrieve_body($sites), true);

  $html = "<table class='widefat'><thead><tr><th>Slug</th><th>URL</th><th>Status</th></tr></thead><tbody>";
  foreach ($body as $site) {
    $html .= "<tr><td>{$site['slug']}</td><td><a href='{$site['url']}' target='_blank'>{$site['url']}</a></td><td>{$site['status']}</td></tr>";
  }
  $html .= "</tbody></table>";
  return $html;
});