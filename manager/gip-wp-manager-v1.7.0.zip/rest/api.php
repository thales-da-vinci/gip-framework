<?php
add_action('rest_api_init', function () {
  register_rest_route('gip/v1', '/sites', array(
    'methods' => 'GET',
    'callback' => 'gip_list_sites',
    'permission_callback' => '__return_true'
  ));

  register_rest_route('gip/v1', '/logs', array(
    'methods' => 'POST',
    'callback' => 'gip_save_log',
    'permission_callback' => '__return_true'
  ));
});

function gip_list_sites() {
  $base = WP_CONTENT_DIR . '/gip-sites/';
  $dirs = glob($base . '*', GLOB_ONLYDIR);
  $list = [];

  foreach ($dirs as $dir) {
    $info = @json_decode(file_get_contents($dir . '/site.json'), true);
    $list[] = [
      'slug' => basename($dir),
      'url' => $info['url'] ?? '',
      'status' => $info['status'] ?? 'indefinido',
      'path' => $dir
    ];
  }

  return $list;
}

function gip_save_log($request) {
  $params = $request->get_json_params();
  $msg = "[" . date('Y-m-d H:i') . "] " . json_encode($params) . "\n";
  file_put_contents(WP_CONTENT_DIR . '/gip-sites/logs.log', $msg, FILE_APPEND);
  return ['success' => true];
}