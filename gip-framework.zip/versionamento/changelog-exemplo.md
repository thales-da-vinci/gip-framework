# Changelog Exemplo

## v1.0
- Estrutura inicial criada.