# Snapshot v1.0

Resumo das funcionalidades da primeira versão.