# Uso de Hooks

Hooks recomendados para integração com o WP.