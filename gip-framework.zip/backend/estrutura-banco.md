# Estrutura do Banco de Dados

Defina tabelas, campos e relações.