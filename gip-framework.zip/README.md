# GIP Framework

Estrutura oficial do GIP Framework para plugins WordPress usando IA.