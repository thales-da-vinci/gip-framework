# Modelo de Prompt

Estrutura base para criação de prompts.