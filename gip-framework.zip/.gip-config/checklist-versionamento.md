# Checklist de Versionamento

- Criar snapshot antes de alterações.