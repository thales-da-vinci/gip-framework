# Instruções de Uso do GIP

Como aplicar o framework em plugins.