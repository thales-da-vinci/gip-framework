# Estrutura de Pastas

Organização recomendada para o plugin.