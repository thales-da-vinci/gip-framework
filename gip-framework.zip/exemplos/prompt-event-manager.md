# Prompt Event Manager

Exemplo completo de prompt.